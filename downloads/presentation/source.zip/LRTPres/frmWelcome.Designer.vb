﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmWelcome
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmWelcome))
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblAuthorName = New System.Windows.Forms.Label()
        Me.lblGroupProject = New System.Windows.Forms.Label()
        Me.pnlSlide1 = New System.Windows.Forms.Panel()
        Me.btnNotes = New System.Windows.Forms.Button()
        Me.wwwData = New System.Windows.Forms.WebBrowser()
        Me.btnPrevious = New System.Windows.Forms.Button()
        Me.btnNext = New System.Windows.Forms.Button()
        Me.rtfData = New System.Windows.Forms.RichTextBox()
        Me.lblLoading = New System.Windows.Forms.Label()
        Me.tmrSplashGo = New System.Windows.Forms.Timer(Me.components)
        Me.pnlSlide1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnExit.Location = New System.Drawing.Point(697, 5)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(21, 25)
        Me.btnExit.TabIndex = 0
        Me.btnExit.Text = "&X"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblAuthorName
        '
        Me.lblAuthorName.AutoSize = True
        Me.lblAuthorName.BackColor = System.Drawing.Color.Transparent
        Me.lblAuthorName.Location = New System.Drawing.Point(6, 9)
        Me.lblAuthorName.Name = "lblAuthorName"
        Me.lblAuthorName.Size = New System.Drawing.Size(93, 13)
        Me.lblAuthorName.TabIndex = 1
        Me.lblAuthorName.Text = "IT 150G - Group 3"
        '
        'lblGroupProject
        '
        Me.lblGroupProject.AutoSize = True
        Me.lblGroupProject.BackColor = System.Drawing.Color.Transparent
        Me.lblGroupProject.Font = New System.Drawing.Font("Cambria", 36.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGroupProject.Location = New System.Drawing.Point(12, 34)
        Me.lblGroupProject.Name = "lblGroupProject"
        Me.lblGroupProject.Size = New System.Drawing.Size(523, 57)
        Me.lblGroupProject.TabIndex = 2
        Me.lblGroupProject.Text = "Light Rail Presentation"
        Me.lblGroupProject.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'pnlSlide1
        '
        Me.pnlSlide1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlSlide1.Controls.Add(Me.btnNotes)
        Me.pnlSlide1.Controls.Add(Me.wwwData)
        Me.pnlSlide1.Controls.Add(Me.btnPrevious)
        Me.pnlSlide1.Controls.Add(Me.btnNext)
        Me.pnlSlide1.Controls.Add(Me.rtfData)
        Me.pnlSlide1.Location = New System.Drawing.Point(9, 95)
        Me.pnlSlide1.Name = "pnlSlide1"
        Me.pnlSlide1.Size = New System.Drawing.Size(708, 203)
        Me.pnlSlide1.TabIndex = 3
        Me.pnlSlide1.Visible = False
        '
        'btnNotes
        '
        Me.btnNotes.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.btnNotes.Location = New System.Drawing.Point(327, 166)
        Me.btnNotes.Name = "btnNotes"
        Me.btnNotes.Size = New System.Drawing.Size(77, 29)
        Me.btnNotes.TabIndex = 4
        Me.btnNotes.Text = "N&otes"
        Me.btnNotes.UseVisualStyleBackColor = True
        '
        'wwwData
        '
        Me.wwwData.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.wwwData.Location = New System.Drawing.Point(0, -1)
        Me.wwwData.MinimumSize = New System.Drawing.Size(20, 20)
        Me.wwwData.Name = "wwwData"
        Me.wwwData.Size = New System.Drawing.Size(705, 160)
        Me.wwwData.TabIndex = 3
        '
        'btnPrevious
        '
        Me.btnPrevious.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnPrevious.Location = New System.Drawing.Point(13, 165)
        Me.btnPrevious.Name = "btnPrevious"
        Me.btnPrevious.Size = New System.Drawing.Size(77, 30)
        Me.btnPrevious.TabIndex = 2
        Me.btnPrevious.Text = "< &Previous"
        Me.btnPrevious.UseVisualStyleBackColor = True
        '
        'btnNext
        '
        Me.btnNext.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnNext.Location = New System.Drawing.Point(628, 165)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(77, 30)
        Me.btnNext.TabIndex = 1
        Me.btnNext.Text = "&Next >"
        Me.btnNext.UseVisualStyleBackColor = True
        '
        'rtfData
        '
        Me.rtfData.Dock = System.Windows.Forms.DockStyle.Top
        Me.rtfData.Location = New System.Drawing.Point(0, 0)
        Me.rtfData.Name = "rtfData"
        Me.rtfData.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical
        Me.rtfData.Size = New System.Drawing.Size(708, 156)
        Me.rtfData.TabIndex = 0
        Me.rtfData.Text = ""
        '
        'lblLoading
        '
        Me.lblLoading.AutoSize = True
        Me.lblLoading.BackColor = System.Drawing.Color.Transparent
        Me.lblLoading.Font = New System.Drawing.Font("Cambria", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLoading.Location = New System.Drawing.Point(194, 9)
        Me.lblLoading.Name = "lblLoading"
        Me.lblLoading.Size = New System.Drawing.Size(149, 25)
        Me.lblLoading.TabIndex = 4
        Me.lblLoading.Text = "Now Loading..."
        '
        'tmrSplashGo
        '
        Me.tmrSplashGo.Interval = 5000
        '
        'frmWelcome
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnExit
        Me.ClientSize = New System.Drawing.Size(723, 306)
        Me.Controls.Add(Me.lblLoading)
        Me.Controls.Add(Me.pnlSlide1)
        Me.Controls.Add(Me.lblGroupProject)
        Me.Controls.Add(Me.lblAuthorName)
        Me.Controls.Add(Me.btnExit)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmWelcome"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Light Rail"
        Me.pnlSlide1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents lblAuthorName As System.Windows.Forms.Label
    Friend WithEvents lblGroupProject As System.Windows.Forms.Label
    Friend WithEvents pnlSlide1 As System.Windows.Forms.Panel
    Friend WithEvents lblLoading As System.Windows.Forms.Label
    Friend WithEvents rtfData As System.Windows.Forms.RichTextBox
    Friend WithEvents btnNext As System.Windows.Forms.Button
    Friend WithEvents btnPrevious As System.Windows.Forms.Button
    Friend WithEvents wwwData As System.Windows.Forms.WebBrowser
    Friend WithEvents tmrSplashGo As System.Windows.Forms.Timer
    Friend WithEvents btnNotes As System.Windows.Forms.Button

End Class
