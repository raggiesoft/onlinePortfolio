﻿Public Class frmWelcome
    ' This is the slide we are currently on
    ' We ALWAYS start at Slide Zero
    Dim iCurrentSlide As Integer = 0

    ' Let's create a space in memory to hold Document locations
    Dim docBase As String

    ' Let's access our Settings file
    Dim ini As New Inifile(My.Application.Info.DirectoryPath & "\settings.ini")

    Private Sub frmWelcome_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        ' At the end of the presentation, let's simply close the window
        ' no questions asked
        If ini.ReadValue("slides", "slide_final") = iCurrentSlide Then
            e.Cancel = False
        Else
            ' Otherwise, verify if the user really wants to quit or not
            If (MessageBox.Show("Are you sure you want to exit?  This is not the last slide!", My.Application.Info.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)) = Windows.Forms.DialogResult.Yes Then

                ' Do NOT cancel the closing window
                ' That is, DO close the Window
                e.Cancel = False
            Else
                ' Cancel the closing - leave the window open
                e.Cancel = True
            End If
        End If
    End Sub

    Private Sub frmWelcome_KeyUp(sender As Object, e As KeyEventArgs) Handles Me.KeyUp
        If e.KeyCode = Keys.Right Or e.KeyCode = Keys.Enter Then
            ' Let's either advance to the next slide
            ' or close the window
            If iCurrentSlide >= ini.ReadValue("slides", "slide_final") Then
                Me.Close()
            Else
                loadSlide(iCurrentSlide + 1)
            End If
        ElseIf e.KeyCode = Keys.Left Then
            If iCurrentSlide <= 1 Then
                MessageBox.Show("You're already at the first slide!", My.Application.Info.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Else
                loadSlide(iCurrentSlide - 1)
            End If
        End If
    End Sub
    Private Sub frmWelcome_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load


        ' We need to set up the default path to find data
        docBase = My.Application.Info.DirectoryPath & "\Files\"

        ' We want our window to take up the entire size of the screen
        Me.WindowState = FormWindowState.Maximized

        ' Let's label the window
        Me.Text = My.Application.Info.ProductName

        ' Let's tell the application how to handle its background image
        Me.BackgroundImageLayout = ImageLayout.Stretch

        ' Which image we should use for the background
        Me.BackgroundImage = Image.FromFile(docBase & "\images\splash\splash.jpg")

        ' While we load everything, we want the Loading label to be dead center
        ' no matter how big or small the system it's running on is
        lblLoading.SetBounds((Me.ClientSize.Width - lblLoading.Width) / 2, (Me.ClientSize.Height - lblLoading.Height) / 2, 0, 0, BoundsSpecified.Location)

        ' While we wait, let's show the Agency name
        lblGroupProject.Text = ini.ReadValue("lrtpres", "project_name")
        lblAuthorName.Text = ini.ReadValue("lrtpres", "author_name") & " - " & ini.ReadValue("lrtpres", "project_name")

        ' Adjust the Font Colors so they can be seen against the background
        lblAuthorName.ForeColor = Color.White
        lblGroupProject.ForeColor = Color.White
        lblLoading.ForeColor = Color.White

        ' Let's turn on the Timer
        tmrSplashGo.Enabled = True
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        ' Let's simply close the Window
        Me.Close()
    End Sub

    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        ' Let's either advance to the next slide
        ' or close the window
        If iCurrentSlide >= ini.ReadValue("slides", "slide_final") Then
            Me.Close()
        Else
            loadSlide(iCurrentSlide + 1)
        End If
    End Sub
    Private Sub loadSlide(iSlideNumber)
        ' Try/Catch in case something goes wrong
        Try
            ' Let's open up settings.ini and ask for the slide type
            Dim fileType As String = ini.ReadValue("slide" & iSlideNumber, "type")

            ' Depending on type (Rich Text File or World Wide Web)
            ' Open the correct viewer and hide the other viewer
            Select Case fileType
                Case "rtf"
                    rtfData.Visible = True
                    rtfData.LoadFile(docBase & "Docs\" & ini.ReadValue("slide" & iSlideNumber, "doc"))
                    wwwData.Visible = False
                Case "www"
                    rtfData.Visible = False
                    wwwData.Visible = True
                    Dim wwwURL As New Uri(docBase & "Docs\" & ini.ReadValue("slide" & iSlideNumber, "doc"))
                    wwwData.AllowNavigation = True
                    wwwData.Navigate(wwwURL)
            End Select

            ' Let's update the Slide Title
            lblGroupProject.Text = ini.ReadValue("slide" & iSlideNumber, "label")

            ' Slide 1 should NOT have the Previous button
            If iSlideNumber < 2 Then
                btnPrevious.Enabled = False
            Else
                btnPrevious.Enabled = True
            End If

            ' The final slide should have a Finish button
            ' NOT a Next button
            If iSlideNumber >= ini.ReadValue("slides", "slide_final") Then
                btnNext.Text = "&Finish"
            Else
                btnNext.Text = "&Next >"
            End If

            ' Make the Notes available if they are here
            If (My.Computer.FileSystem.FileExists(docBase & "Docs\Notes\slide" & iSlideNumber & ".txt") = False) Then
                btnNotes.Enabled = False
            Else
                btnNotes.Enabled = True
            End If

            ' Update the Slide number
            iCurrentSlide = iSlideNumber

            ' Lastly, let's alert the user if there's no network
            If (My.Computer.Network.IsAvailable = False) Then
                If ini.ReadValue("slides" & iSlideNumber, "require_network") = "yes" Then
                    MessageBox.Show("This computer is not connected to the internet, and the slide you are about to view needs a connection in order to view properly." & vbCrLf & "" & vbCrLf & "The slide will show, however it may not show up as you expected it to.", My.Application.Info.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                End If
            End If
        Catch
            ' If there's an error, alert the user
            MessageBox.Show("The slide you asked for does not exist!", My.Application.Info.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
    End Sub

    Private Sub btnPrevious_Click(sender As Object, e As EventArgs) Handles btnPrevious.Click
        ' Let's either advance to the next slide
        ' or close the window
        If iCurrentSlide <= 1 Then
            MessageBox.Show("You're already at the first slide!", My.Application.Info.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            loadSlide(iCurrentSlide - 1)
        End If
    End Sub

    Private Sub frmWelcome_Resize(sender As Object, e As EventArgs) Handles Me.Resize
        ' If the window gets resized, we need the viewers to have
        ' the correct width and height to take up the entire screen
        rtfData.Width = pnlSlide1.Width
        rtfData.Height = pnlSlide1.Height - btnNext.Height - 10
        wwwData.Width = pnlSlide1.Width
        wwwData.Height = pnlSlide1.Height - btnNext.Height - 10
    End Sub

    Private Sub tmrSplashGo_Tick(sender As Object, e As EventArgs) Handles tmrSplashGo.Tick
        ' When the Splash screen is over (5 seconds)
        ' Let's show the first slide
        ' first, we need to turn ON the data panel and turn OFF
        ' the Now Loading message

        pnlSlide1.Visible = True
        lblLoading.Visible = False

        ' let's correct the size of the two viewers
        rtfData.Width = pnlSlide1.Width
        rtfData.Height = pnlSlide1.Height - btnNext.Height - 10
        wwwData.Width = pnlSlide1.Width
        wwwData.Height = pnlSlide1.Height - btnNext.Height - 10

        ' Load the first slide
        loadSlide(1)

        ' Let's set up the Cancel and Default buttons
        Me.CancelButton = btnExit
        Me.AcceptButton = btnNext

        ' Move the Focus to the Next button
        Me.ActiveControl = btnNext

        ' Turn the timer off
        tmrSplashGo.Enabled = False
    End Sub

    Private Sub btnNotes_Click(sender As Object, e As EventArgs) Handles btnNotes.Click
        Try
            Dim fileContents As String
            fileContents = My.Computer.FileSystem.ReadAllText(docBase & "Docs\Notes\slide" & iCurrentSlide & ".txt")
            frmNotesViewer.txtNotes.Text = fileContents
            frmNotesViewer.Text = "Slide " & iCurrentSlide & " - Slide Notes Viewer"
            frmNotesViewer.ShowDialog()
        Catch
            MessageBox.Show("The notes you asked for don't exist!", My.Application.Info.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
    End Sub

    Private Sub btnPrevious_KeyUp(sender As Object, e As KeyEventArgs) Handles btnPrevious.KeyUp
        If e.KeyCode = Keys.Left Then
            ' Let's either advance to the next slide
            ' or close the window
            If iCurrentSlide <= 1 Then
                MessageBox.Show("You're already at the first slide!", My.Application.Info.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Else
                loadSlide(iCurrentSlide - 1)
            End If
        End If
    End Sub

    Private Sub btnNext_KeyUp(sender As Object, e As KeyEventArgs) Handles btnNext.KeyUp
        If e.KeyCode = Keys.Right Then
            ' Let's either advance to the next slide
            ' or close the window
            If iCurrentSlide >= ini.ReadValue("slides", "slide_final") Then
                Me.Close()
            Else
                loadSlide(iCurrentSlide + 1)
            End If
        End If
    End Sub



End Class
