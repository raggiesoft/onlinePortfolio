﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmWelcome
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmWelcome))
        Me.btnExit = New System.Windows.Forms.Button
        Me.lblClassName = New System.Windows.Forms.Label
        Me.lblGroupProject = New System.Windows.Forms.Label
        Me.pnlData = New System.Windows.Forms.Panel
        Me.SplashGo = New System.Windows.Forms.Timer(Me.components)
        Me.lblLoading = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnExit.Location = New System.Drawing.Point(424, 5)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(21, 25)
        Me.btnExit.TabIndex = 0
        Me.btnExit.Text = "&X"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblClassName
        '
        Me.lblClassName.AutoSize = True
        Me.lblClassName.BackColor = System.Drawing.Color.Transparent
        Me.lblClassName.Location = New System.Drawing.Point(6, 9)
        Me.lblClassName.Name = "lblClassName"
        Me.lblClassName.Size = New System.Drawing.Size(93, 13)
        Me.lblClassName.TabIndex = 1
        Me.lblClassName.Text = "IT 150G - Group 3"
        '
        'lblGroupProject
        '
        Me.lblGroupProject.AutoSize = True
        Me.lblGroupProject.BackColor = System.Drawing.Color.Transparent
        Me.lblGroupProject.Font = New System.Drawing.Font("Brush Script MT", 36.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGroupProject.Location = New System.Drawing.Point(12, 34)
        Me.lblGroupProject.Name = "lblGroupProject"
        Me.lblGroupProject.Size = New System.Drawing.Size(426, 59)
        Me.lblGroupProject.TabIndex = 2
        Me.lblGroupProject.Text = "Light Rail Presentation"
        '
        'pnlData
        '
        Me.pnlData.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlData.Location = New System.Drawing.Point(9, 95)
        Me.pnlData.Name = "pnlData"
        Me.pnlData.Size = New System.Drawing.Size(435, 203)
        Me.pnlData.TabIndex = 3
        Me.pnlData.Visible = False
        '
        'SplashGo
        '
        '
        'lblLoading
        '
        Me.lblLoading.AutoSize = True
        Me.lblLoading.BackColor = System.Drawing.Color.Transparent
        Me.lblLoading.Font = New System.Drawing.Font("Monotype Corsiva", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLoading.Location = New System.Drawing.Point(194, 9)
        Me.lblLoading.Name = "lblLoading"
        Me.lblLoading.Size = New System.Drawing.Size(144, 25)
        Me.lblLoading.TabIndex = 4
        Me.lblLoading.Text = "Now Loading..."
        '
        'frmWelcome
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(450, 306)
        Me.Controls.Add(Me.lblLoading)
        Me.Controls.Add(Me.pnlData)
        Me.Controls.Add(Me.lblGroupProject)
        Me.Controls.Add(Me.lblClassName)
        Me.Controls.Add(Me.btnExit)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmWelcome"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Light Rail"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents lblClassName As System.Windows.Forms.Label
    Friend WithEvents lblGroupProject As System.Windows.Forms.Label
    Friend WithEvents pnlData As System.Windows.Forms.Panel
    Friend WithEvents SplashGo As System.Windows.Forms.Timer
    Friend WithEvents lblLoading As System.Windows.Forms.Label

End Class
