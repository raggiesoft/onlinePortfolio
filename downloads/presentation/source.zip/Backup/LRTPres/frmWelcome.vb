﻿Public Class frmWelcome

    Private Sub frmWelcome_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        SplashGo.Interval = 5000
        SplashGo.Enabled = True
        Me.WindowState = FormWindowState.Maximized
        Me.Text = My.Application.Info.ProductName
        Me.BackgroundImageLayout = ImageLayout.Stretch
        Me.BackgroundImage = Image.FromFile(My.Application.Info.DirectoryPath & "\images\splash\splash" & getSplashImage() & ".jpg")
        lblLoading.SetBounds((Me.ClientSize.Width - lblLoading.Width) / 2, (Me.ClientSize.Height - lblLoading.Height) / 2, 0, 0, BoundsSpecified.Location)
        lblGroupProject.Text = "How Feeder Buses Extend Light Rail Service"
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub SplashGo_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SplashGo.Tick
        pnlData.Visible = True
        lblLoading.Visible = False
        SplashGo.Enabled = False
    End Sub
End Class
