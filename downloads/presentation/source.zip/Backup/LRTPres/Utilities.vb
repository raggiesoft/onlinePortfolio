﻿Module Utilities

    ''' <summary>
    ''' This function returns a random number, between 1 and 3, that lets us see the splash screen
    ''' </summary>
    ''' <returns>Random Number between 1 and 3</returns>
    ''' <remarks></remarks>
    Public Function getSplashImage() As Integer
        Dim RandomClass As New Random()
        Dim RandomNumber As Integer
        RandomNumber = RandomClass.Next(1, 3)
        Return RandomNumber
    End Function
    
End Module
